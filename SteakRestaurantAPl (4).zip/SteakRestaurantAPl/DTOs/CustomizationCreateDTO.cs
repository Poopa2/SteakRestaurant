﻿public class CustomizationCreateDTO
{
    public int OrderItemId { get; set; }
    public string Note { get; set; } = null!;
}

