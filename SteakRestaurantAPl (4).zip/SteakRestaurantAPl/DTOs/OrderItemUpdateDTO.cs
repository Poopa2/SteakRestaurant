﻿namespace SteakRestaurantAPI.DTOs
{
    public class OrderItemUpdateDTO : OrderItemCreateDTO
    {
        public int Id { get; set; }
    }
}
