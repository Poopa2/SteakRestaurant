﻿namespace SteakRestaurantAPI.DTOs
{
    public class CustomizationUpdateDTO : CustomizationCreateDTO
    {
        public int Id { get; set; }
    }
}
