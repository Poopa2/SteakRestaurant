﻿namespace SteakRestaurantAPI.DTOs
{
    public class ProductUpdateDTO : ProductCreateDTO
    {
        public int Id { get; set; }
    }
}
