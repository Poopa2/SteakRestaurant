import { createRoot } from "react-dom/client";
import StorefrontPage from "./pages/StorefrontPage";
createRoot(document.getElementById("root")!).render(<StorefrontPage />);
