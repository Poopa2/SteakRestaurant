import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { register } from "../auth";

export default function RegisterPage() {
  const nav = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    try {
      await register(username.trim(), password);
      nav("/login"); // สมัครเสร็จไปหน้า Login
    } catch (e: any) {
      setErr(e?.message || "สมัครไม่สำเร็จ");
    }
  }

  return (
    <div style={{ minHeight: "100vh", background: "#111", color: "#f5d742", display: "grid", placeItems: "center" }}>
      <form onSubmit={onSubmit} style={{ background: "#222", padding: 24, borderRadius: 12, width: 360, boxShadow: "0 8px 24px rgba(0,0,0,.4)" }}>
        <h2 style={{ marginTop: 0 }}>สมัคร</h2>
        <label>ชื่อผู้ใช้</label>
        <input value={username} onChange={e=>setUsername(e.target.value)} required
               style={{ width: "100%", padding: 10, borderRadius: 8, border: "1px solid #444", margin: "6px 0 12px" }}/>
        <label>รหัสผ่าน</label>
        <input type="password" value={password} onChange={e=>setPassword(e.target.value)} required
               style={{ width: "100%", padding: 10, borderRadius: 8, border: "1px solid #444", margin: "6px 0 16px" }}/>
        {err && <div style={{ color: "#ff8a8a", marginBottom: 12 }}>{err}</div>}
        <button type="submit" style={{ width: "100%", padding: 12, borderRadius: 10, border: "none", background: "linear-gradient(45deg,#f5d742,#d4b942)", color:"#111", fontWeight:700 }}>
          Register
        </button>
        <div style={{ marginTop: 12 }}>
          มีบัญชีแล้ว? <Link to="/login">เข้าสู่ระบบ</Link>
        </div>
      </form>
    </div>
  );
}
